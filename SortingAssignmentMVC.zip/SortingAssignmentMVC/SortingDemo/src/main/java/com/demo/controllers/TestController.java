package com.demo.controllers;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller()
public class TestController {
	/*
	 * @Autowired SortDetailsRepo sortDetailsRepo;
	 */
	@RequestMapping("/")
	public ModelAndView firstPage() throws IOException {
		File file = new File("src\\main\\java\\com\\demo\\controllers\\LastVal.txt"); 
		  
		  BufferedReader br = new BufferedReader(new FileReader(file)); 
		  
		  String st =""; 
		/*
		 * while ((st = br.readLine()) != null) { System.out.println(st); }
		 */
		  if((st = br.readLine()) != null) {
			  return new ModelAndView("welcome").addObject("LastVal", st);
		  } else		return new ModelAndView("welcome");
	}

	@RequestMapping("/getRandomNumber")
	public ModelAndView secondPage() {
		ArrayList<Integer> list = new ArrayList<Integer>();
		Random NumGenerator = new Random();
		for (int i = 0; i < 50; i++) {
			int number = NumGenerator.nextInt(100);
			list.add(number);
			System.out.println(list.get(i).toString());
		}
		return new ModelAndView("RandomNumber").addObject("list", list);
	}

	@GetMapping("/getPreviousData")
	public @ResponseBody ArrayList<Integer> getPreviousData() {
		ArrayList<Integer> previousData = new ArrayList<Integer>();
		previousData.add(9);
		return previousData;

	}

	/*
	 * @RequestMapping(value = "/sort") public @ResponseBody ArrayList<Integer>
	 * sort(@ModelAttribute(value = "list") ArrayList<Integer> list) {
	 * Collections.sort(list);
	 * 
	 * SortDetails sortDetails = new SortDetails(); sortDetails.setSortedList(list);
	 * sortDetailsRepo.deleteAll(); sortDetailsRepo.save(sortDetails);
	 * 
	 * return list;
	 * 
	 * }
	 */

	@RequestMapping(value = "/sort")
	public ModelAndView sort(@ModelAttribute(value = "list") ArrayList<Integer> list) throws IOException {
		Collections.sort(list);
		
		if (!list.isEmpty()) {
			String s = "";
			for (int i = 0; i < list.size(); i++) {
				if (i == list.size() - 1) {
					s = s + list.get(i);
				} else {
					s = s + list.get(i) + " , ";
				}

			}
			FileWriter fw = new FileWriter("src\\main\\java\\com\\demo\\controllers\\LastVal.txt");
			fw.write(s);
			fw.flush();
			fw.close();
		}
		return new ModelAndView("SortedNumbers").addObject("list", list);

	}
}
